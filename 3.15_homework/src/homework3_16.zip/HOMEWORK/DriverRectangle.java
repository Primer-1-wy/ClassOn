package HOMEWORK;

public class DriverRectangle {
    public static void main(String args[])
    {
        Rectangle test1 =new Rectangle();
        Rectangle test2 =new Rectangle(1,1);
        Rectangle test3 =new Rectangle(2,2);
        Rectangle test4 =new Rectangle(2,3);
        Rectangle test5 =new Rectangle(10,60);

        System.out.println(test1);
        System.out.println(test2);
        System.out.println(test3);
        System.out.println(test4);
        System.out.println(test5);


    }

}
